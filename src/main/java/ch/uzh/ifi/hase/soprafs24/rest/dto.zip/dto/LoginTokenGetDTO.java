package ch.uzh.ifi.hase.soprafs24.rest.dto;

public class LoginTokenGetDTO {

  private String token;

  public String getToken(){
    return token;
  }

  public void setToken(String token){
    this.token = token;
  }
  
}
