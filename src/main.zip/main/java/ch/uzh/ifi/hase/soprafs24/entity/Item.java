// package ch.uzh.ifi.hase.soprafs24.entity;

// import javax.persistence.Column;
// import javax.persistence.MappedSuperclass;

// @MappedSuperclass
// public abstract class Item {

//     @Column(nullable = false)
//     private int points;

//     public Item() {}

//     public Item(int points) {
//         this.points = points;
//     }

//     public int getPoints() {
//         return points;
//     }

//     public void setPoints(int points) {
//         this.points = points;
//     }
// }
