package ch.uzh.ifi.hase.soprafs24.constant;

public enum UserStatus {
  ONLINE, OFFLINE;
}
